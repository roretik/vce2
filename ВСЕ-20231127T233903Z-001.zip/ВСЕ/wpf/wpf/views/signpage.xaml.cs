﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wpf.bases;
using wpf.views;

namespace wpf.views
{
    /// <summary>
    /// Логика взаимодействия для signpage.xaml
    /// </summary>
    public partial class signpage : Page
    {
        public signpage()
        {
            InitializeComponent();
        }
        private void sighclick(object sender, RoutedEventArgs e)
        {
            var CurrentUser = appdata.db.users.FirstOrDefault(u => u.C_login == Tlogin.Text && u.pass == Tpassword.Text);
           
            if (CurrentUser != null)
            {
                NavigationService.Navigate(new AdminDataPage());
            }
            else
            {
                MessageBox.Show("вы не зарегестрированы");
            }
        }
        private void registerclick(object sender, RoutedEventArgs e)
        {
            users people = new users();

            people.C_login = Tlogin.Text;
            people.pass = Tpassword.Text;
            people.id_type = 2;

            appdata.db.users.Add(people);
            appdata.db.SaveChanges();
            MessageBox.Show("вы зарегестрировались");
        }
    }
    
}
