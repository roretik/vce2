﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpf.views
{
    /// <summary>
    /// Логика взаимодействия для AdminDataPage.xaml
    /// </summary>
    public partial class AdminDataPage : Page
    {
        public AdminDataPage()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
        private void Button_Users(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminUsers());
        }
        private void Button_UsersType(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminUsersType());
        }
        private void Button_Employee(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminEmployee());
        }
        private void Button_Employeeinfo(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminEmployeeInfo());
        }
        private void Button_Pokypka(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminPokypka());
        }
        private void Button_ProdazhaType(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminProdazhaType());
        }
        private void Button_Proffesion(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AdminProffesion());
        }
        private void Button_usl(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Adminusl());
        }
    }
}
