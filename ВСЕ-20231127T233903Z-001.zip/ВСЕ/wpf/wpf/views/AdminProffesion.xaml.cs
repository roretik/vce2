﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wpf.bases;

namespace wpf.views
{
    /// <summary>
    /// Логика взаимодействия для AdminProffesion.xaml
    /// </summary>
    public partial class AdminProffesion : Page
    {
        public AdminProffesion()
        {
            InitializeComponent();
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            usersgrid.ItemsSource = appdata.db.profession.ToList();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
        private void Button_remove(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("вы действительно хотите удалить данные?", "уведомление", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            {
                var currentuser = usersgrid.SelectedItem as profession;
                appdata.db.profession.Remove(currentuser);
                appdata.db.SaveChanges();

                usersgrid.ItemsSource = appdata.db.profession.ToList();
                MessageBox.Show("успешно выполнено");
            }
        }
    }
}
