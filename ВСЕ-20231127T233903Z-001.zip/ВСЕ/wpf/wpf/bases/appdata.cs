﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpf.bases
{
    public static class appdata
    {
        public static KostikEntities db = new KostikEntities();
    }
}